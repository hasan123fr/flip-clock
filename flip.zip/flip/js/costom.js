var clock = $('.clock').FlipClock({
    clockFace: 'TwelveHourClock'
});